Matlab code to learn binary hash functions independently by assigning each function
a local subset of points which is different from the rest of the subsets.

(C) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan
    Electrical Engineering and Computer Science
    University of California, Merced
    http://eecs.ucmerced.edu

The functions in this package can be used to optimize the same single-bit 
affinity-based objective function b times independently. It creates local subsets
as the training subsets. The resulting hash function can be used to map input
vectors to binary codes, as a hash function, and thus to do binary hashing for
fast approximate information retrieval.

Reference:
  R. Raziperchikolaei and  M. A. Carreira-Perpinan: "Learning independent, 
  diverse binary hash functions: pruning and locality".

The main function is ilh_local.m. See the function for detailed usage
instructions. The script demo.m illustrates how to use it to train hash 
function and do binary hashing using a subset of the CIFAR dataset contained
in the file CIFARsubset.mat.

List of functions:
- demo.m: trains hash functions on the CIFAR subset using ilh_local and ilh 
  (without locality) and plots their K-nearest-neighbor precision for 32 bits.
- ilh_local.m (in AUX/): learns b single bit hash functions independently from each
  other by minimizing the same objective b times. It makes the functions 
  diverse by using different "local" training subsets for the hash functions.

The training algorithm depends on the following functions (in AUX/):
- ilh: same as ilh_local, except that the training subsets are not local.
- hOpt: train the hash function given input data and binary codes.
- KNNPrecision: compute K-nearest-neighbor precision.
- linh: apply a linear hash function to a data matrix and return binary codes.
- sqdist: computes the Euclidean distance between two sets of points.
- quad_surrogate: solves a binary quadratic problem approximately using 
  qudratic surrogate method.
- wlinfer_lbfgsb_calc_grad.m: retruns the gradient of a quadratic objective.
  This function is used in the lbfgsb library.
- wlinfer_lbfgsb_calc_obj.m: retruns the value of a quadratic objective.
  This function is used in the lbfgsb library.

Notes:
- The training algorithm achieves a significant speedup if run in parallel.
  If you have the Matlab Parallel Processing Toolbox, simply start 'parpool'
  with the appropriate number of processors (see demo.m), and the iterations
  of every "parfor" loop in the code will be run in parallel. The code will
  run like a normal (serial) "for" if you don't have the Matlab Parallel
  Processing Toolbox.
- The code currently uses a linear (thresholded) hash function.
  You can use a nonlinear function by providing a corresponding
  training function in the step over the function.
- The code curently optimizes the binary quadratic objective using the
  quadratic surrogate method. You can use other solvers by changing the 
  step over the codes and replacing the quad_surrogate.m with a new 
  function (look at the ilh.m)

Installation notes:
- We train linear SVMs using LIBLINEAR:
    Fan et al: "LIBLINEAR: a library for large linear classification",
    JMLR 2008, http://www.csie.ntu.edu.tw/~cjlin/liblinear
  and its extension for incremental learning:
    Tsai et al: "Incremental and decremental training for linear
    classification", KDD 2014, http://www.csie.ntu.edu.tw/~cjlin/papers/ws.
  We have provided a Matlab wrapper (matlab/train.c) for the latter by
  modifying the original LIBLINEAR Matlab wrapper.
- We solve the constrained quadratic problem using the a MATLAB interface
  for L-BFGS-B. Details can be found at https://github.com/pcarbo/lbfgsb-matlab
- Quick-start instructions:
  1. Install LIBLINEAR:
     change to liblinear-warmstart-1.95/, run 'make'.
  2. Install the Matlab interface of LIBLINEAR:
     change to liblinear-warmstart-1.95/matlab/, run 'make'.
     Make sure MATLABDIR (in Makefile) matches your Matlab filesystem.
  3. To install LBFGS-B, you need to have g++-4.7 and gfortran-4.7 because 
     the version currently supported with MEX is '4.7.x'. 
     Install them using the commands 'sudo apt-get install g++-4.7' and 
     'sudo apt-get install g++-4.7'.
  4. Then create new symbolic links to them. Change to the usr/bin and run:
     'sudo ln -s g++-4.7 g++' and 'sudo ln -s gfortran-4.7 gfortran'.
  5. Install LBFGS-B library. change to lbfgsb-matlab-master/src, run 'make mex'.
     Make sure MATLABDIR (in Makefile) matches your Matlab filesystem.       
     You may need to first install g++-4.7 () and gfortran-4.7 ()
  6. Change to 'lbfgsb-matlab-master/src', and change name of the file 
     'lbfgsb_mex.mexa64' to 'lbfgsb.mexa64'.
  7. Run our code:
     change to the main directory, run 'demo.m'.
     It should take around 30 seconds to run in a workstation.

