% objfv=wlinfer_lbfgsb_calc_obj(w, aux_data)
%
% Compute the value of the quadratic objective function given the input vector w.
% This function is only used inside the LBGS-B library.
% Look at the file 'lbfgsb-matlab-master/src/lbfgsb.m' for more details.
%
% In:
%   w: Nx1 vecotr of input data.
%   aux_data: a cell array with three elements:
%      aux_data{1}: NxN matrix containing the quadratic coefficients.
%      aux_data{2}: Nx1 vector containing the linear coefficients.
%      aux_data{3}: the sclare value which is the penalty parameter.
%       
% Out:
%   objfv: value of the quadratic objective function.

% Copyright (c) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan

function objfv=wlinfer_lbfgsb_calc_obj(w, aux_data)
conn_map=aux_data{1};hx=aux_data{2};mu=aux_data{3};
objfv=w'*conn_map*w -2*(mu*w'*hx);
end
