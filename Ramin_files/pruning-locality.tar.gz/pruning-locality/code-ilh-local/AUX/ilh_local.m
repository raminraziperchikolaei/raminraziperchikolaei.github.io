% [h] = ilh_local(X,Y,b,sN)
%
% Optimize b single-bit objective function independently to learn a b-bit
% hash function. It assigns local subset of points to each hash function.
%
% Notes:
% - To have faster optimization over codes, the affinity matrix Y should be
%   sparse.
% - To select the local subset of points for a hash function, we first
%   randomly select a point (seed) and consider its SN-1 nearest neighbors (and
%   the seed itself) as the training subset.
%
% In:
%   X: NxD matrix containing N D-dim data points rowwise, the base set.
%   Y: NxN affinity matrix. Contains neighborhood information of the
%      tarining data. The (i,j)th element of Y is 1,-1 or 0 if point i and j
%      are similar, dissimilar, or not related, respectively.
%   b: number of bits in the Hamming space (= number of binary hash functions).
%   sN: size of the training subset to train each hash function.
% Out:
%   h: hash function. It is a struct with parameters:
%      type = 'linh', W = weight matrix (of bxD), w = bias vector (of bx1).

% Any non-mandatory argument can be given the value [] to force it to take
% its default value.

% Copyright (c) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan

function [h] = ilh_local(X,Y,b,sN)

mkdir BAtemp %Create a temporary folder for liblinear files

[N,D]=size(X);  % N=size of the base set, D=dimension of points.

%Weights and bias of the final b-bit hash function.
W = zeros(b,D); w = zeros(b,1);

%main loop
for l=1:b
	%construct the training set: select the seed and find its nearest neighbors
  sidx = randperm(N,1); %seed index
  x = X(sidx,:); sdist = sqdist(x,X); %distance between seed and all the points.
  % find its SN nearest neghbors, which includes the seed itself.
  [~,idx] = sort(sdist,2); idx=idx(1:sN); 
  sX=X(idx,:);  SX=sparse(sX); %sX is the subset of points.
  sY = Y(idx,:); sY = sY(:,idx);  %extract its affinity matrix

	%Learn the binary codes
	%We minimize the laplacian loss -z'Az to learn the codes using the
	%quadratic surrogate method.
  z = quad_surrogate(-sY);
	
	%Learn the hash function given the codes by training SVMs
  [th,~] = hOpt(z,SX);
  W(l,:)=th.W; w(l,1)=th.w; %extract the weights of the 1-bit hash function.
end
h.type='linh'; h.W=W;h.w=w;

delete('BAtemp/*'); rmdir BAtemp %remove the temporary folder
end

