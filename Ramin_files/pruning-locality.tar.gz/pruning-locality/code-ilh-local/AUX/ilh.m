% [h] = ilh(X,Y,b,sN)
%
% Optimize b single-bit objective function independently to learn a b-bit
% hash function.
%
% Notes:
% - To have faster optimization over codes, the affinity matrix Y should be
%   sparse.
% - To select the random subset of points for each hash function, we first
%   generate N random indices and call it idx. The overlapping windows of size
%   sN over idx determines the index of training subsets.
%
% In:
%   X: NxD matrix containing N D-dim data points rowwise, the base set.
%   Y: NxN affinity matrix. Contains neighborhood information of the
%      tarining data. The (i,j)th element of Y is 1,-1 or 0 if point i and j
%      are similar, dissimilar, or not related, respectively.
%   b: number of bits in the Hamming space (= number of binary hash functions).
%   sN: size of the training subset to train each hash function.
% Out:
%   h: hash function. It is a struct with parameters:
%      type = 'linh', W = weight matrix (of bxD), w = bias vector (of bx1).

% Any non-mandatory argument can be given the value [] to force it to take
% its default value.

% Copyright (c) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan

function [h] = ilh(X,Y,b,sN)

mkdir BAtemp %Create a temporary folder for liblinear files

[N,D]=size(X);  % N=size of the base set, D=dimension of points.

%To determine the training subset indices:
idx = randperm(N);
slide = floor((N-sN)/(b-1));

%Weights and bias of the final b-bit hash function.
W = zeros(b,D); w = zeros(b,1);

%main loop
for l=1:b
	%put the window over idx from st to en.
  st = 1+(l-1)*slide; en = st + sN-1; sidx = idx(st:en);
  sX=X(sidx,:);  SX=sparse(sX); % extract training subset
  sY = Y(sidx,:); sY = sY(:,sidx);  %extract its affinity matrix

	%Learn the binary codes
	%We minimize the laplacian loss -z'Az to learn the codes using the
	%quadratic surrogate method.
  z = quad_surrogate(-sY);
	
	%Learn the hash function given the codes by training SVMs
  [th,~] = hOpt(z,SX);
  W(l,:)=th.W; w(l,1)=th.w; %extract the weights of the 1-bit hash function.
end
h.type='linh'; h.W=W;h.w=w;

delete('BAtemp/*'); rmdir BAtemp %remove the temporary folder
end

