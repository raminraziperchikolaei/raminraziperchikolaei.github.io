% [Z,Zsim] = ZOpt(Y,hX,mu[,Z,Zsim])
%
% Optimizes an NP-complete binary optimization problem, which is defined 
% based on the loss function and the output of hash function (equation in 
% line 157 of the paper or equation (3) of the supplemntary material).
%
% Notes:
% - To solve this problem, we use altenating optimization over each bit,
%   given the rest of the bits are fixed. For each bitm we need to solve a
%   binary quadratic problem.
% - We use KSH (BRE) loss function and solve the binary quadratic problem
%   using quadratic surroagte solver. To change the loss function or
%   solver, we need to change one line of the code in this function
%   (look at below).
% - Since the binary optimziation problem is NP-complete, we solve it
%   approximately. This algorithm needs an initialization Z for the binary
%   codes. By default we set Z to all ones.
%   
%
% In:
%   Y: NxN affinity matrix. Contains neighborhood information of the
%      tarining data. The (i,j)th element of Y is 1,-1 or 0 if point i and j
%      are similar, dissimilar, or not related, respectively.
%   hX: Nxb matrix containing output of b-bit hash function in (-1/1)
%   mu: the penalty parameter value of the MAC algorithm.
%   Z: Nxb binary matrix containing N b-bit binary data points (-1/1) rowwise
%      (initial codes). Default: all ones.
%   Zsim: NxN matrix. (i,j)th element is the dot product of z_i and z_j if 
%      i-th and j-th points are related to each other (means that if (i,j)th
%      element of Y is 1 or -1), and 0 otherwise
% Out:
%   Z: Nxb binary matrix of (1/-1), output of the optimization algorithm.
%   Zsim: NxN matrix contains the dot product of the codes of the related 
%      points.

% Any non-mandatory argument can be given the value [] to force it to take
% its default value.

% Copyright (c) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan
function [Z,Zsim] = ZOpt(Y,hX,mu,Z,Zsim)

[r,c] = find(Y~=0); % find the nonzero element of affinity matrix Y
[N,b] = size(hX);

% ---------- Argument defaults ----------
if ~exist('Z','var') || isempty(Z) || ~exist('Zsim','var') || isempty(Zsim) 
  Z = ones(N,b);temp=sum(Z(r,:).*Z(c,:),2); Zsim = sparse(r,c,temp,N,N);
end;
% ---------- End of "argument defaults" ----------

% Alternating optimization over the ith bits
for i = 1 : b
  hx = hX(:,i); z = Z(:,i);
  
  %remove the ith bit from the dot product of the codes in Zsim
  %this is like fixing all the bits except the ith bit.
  temp=sum(z(r).*z(c),2); temp = sparse(r,c,temp,N,N);
  Zsim = Zsim-temp;
  
  % construct matrix A in the binary quadratic problem (eq 5 of the paper)
  % We create A based on the KSH (BRE) loss. If you want to use other loss
  % functions, you have to change this line and create the corresponding
  % matrx A.
  A =  sparse(-(Y-Zsim/b));
  
  %The binary quadratic problem solver has to be called here. We solve it
  % using quadratic surrogate method here. This can be changed to graph-cut
  % algorithm (or other algorithms) easily.
  z = quad_surrogate(A,hx,mu);
  
  Z(:,i)= z; %update the ith bet of the codes
  
  %update the Zsim (dot product of the codes)
  temp=sum(z(r).*z(c),2); temp = sparse(r,c,temp,N,N);
  Zsim = Zsim+temp;
end
end