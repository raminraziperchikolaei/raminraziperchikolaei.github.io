Matlab code to prune a set of hash functions.

(C) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan
    Electrical Engineering and Computer Science
    University of California, Merced
    http://eecs.ucmerced.edu

The functions in this package can be used to prune a set of hash functions and
give us a subset of them that works wel in retrieval tasks.

Reference:
  R. Raziperchikolaei and  M. A. Carreira-Perpinan: "Learning independent, 
  diverse binary hash functions: pruning and locality".

The main function is bhprune.m. See the function for detailed usage
instructions. The script demo.m illustrates how to use it to prune a set of 
hash functions that already had been trained.

List of functions:
- demo.m: It loads the output binary codes of a hashing method (ilh here) on a
  training set, validation set, and test set. It shows the K-nearest-neighbor
  precision for 8 bits before and after pruning.
- bhprune.m:  prunes a set of 1-bit hash functions. Pruning can be applied to
  the output of any hashing method. To prune the hash functions, bhprune only 
  needs the output binary codes of the hash function on a validation and training 
  set.
- KNNPrecision: compute K-nearest-neighbor precision.

Installation notes:
  . Run our code:
     change to the main directory, run 'demo.m'.
     It should take around 30 seconds to run in a workstation.

