% We optimize an affinity-based objective objective function (KSH loss)
% with MAC on a subset of the CIFAR dataset. Here, we implement the MACquad
% (solves Z-step using quadratic surrogate) and compare it with the
% two-step method quad.
% The script should take around 120 seconds to run.

addpath('liblinear-warmstart-1.95/matlab','AUX','lbfgsb-matlab-master/src/');

% Load dataset: 
% X: N*d input data. Here we have N=2000 and d=320 .
% Y: N*N affinity matrix. Sparse affinity-matrices lead to faster training.
%    Here, each point has 100 similar neighbors and 500 dissimilar ones.
% Test: M*d test set. Here we have M = 2000 and d = 320 .
% TY: M*N ground-truth affinity used for computing precision.  
load 'CIFARsubset.mat'; 

b = 8;			% Number of bits in the hash function
N=size(X,1); % Number of training points
Z = ones(N,b); % initialization of binary codes

% Method needs a schedule for the penalty parameter mu, ie a list
% of nondecreasing positive values, where mu(k) is the mu value in the kth
% iteration of the MAC algorithm
iters = 0:1:25; mu = 2.^iters; mu=[0 mu*.3];

% Train MACquad
[mach,macZ] = machash(X,Y,b,mu,Z);
macZ = linh(X,mach); macZ_Test= linh(Test,mach); %Binary codes of macquad

%train two-step method quad
mu=[0 0];
[quadh,quadZ] = machash(X,Y,b,mu,Z);
quadZ = linh(X,quadh); quadZ_Test= linh(Test,quadh); %Binary codes of quad

% Compute the precision
K=[50:50:200]; % Number of neighbors to retrieve
macP = KNNPrecision(macZ,macZ_Test,K,TY);
quadP = KNNPrecision(quadZ,quadZ_Test,K,TY);

% ...and plot the results.
prec=[macP;quadP];
figure(1); h = plot(K,prec); set(gca,'XTick',K);
xlabel('number of neighbors'); ylabel('precision');
legend(h,'MACquad','quad','Location','NorthEast');
