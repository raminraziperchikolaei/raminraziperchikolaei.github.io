function callbackMFLDA (t, f, xi, gamma, Phi, auxdata)
  fprintf('%3d [%0.3f] \n',t,-f);
  