% ilh-local learns b 1-bit hash functions independently. It makes the 1-bit hash
% functions different from each other by assigning different training subsets of
% points to different hash function. ilh-local creates the training subset by
% choosing points that are spatially local.

%See README file to install the libraries correctly
addpath('AUX','liblinear-warmstart-1.95/matlab','lbfgsb-matlab-master/src/');

% Load dataset that contains: 
% X: N*d input data. Here we have N=5000 and d=320 .
% Y: N*N affinity matrix. Sparse affinity matrices lead to faster training.
%    Here, each point has 100 similar neighbors and 100 dissimilar ones.
% Test: M*d test set. Here we have M = 2000 and d = 320 .
% TY: M*N ground-truth affinity used for computing precision.  
load('CIFARsubset.mat');

%The algorithm is massively parallel. If you have parallel processing
%toolbox, then set the parpool,
%parpool(2)

b = 32;			% Number of bits in the hash function

%ilh parameter: size of the training subset for each hash functions
sN=500;

%Learn ilh_local hash functions
h_local = ilh_local(X,Y,b,sN);
%Binary codes of ilh_local for training and test points
Z_local = linh(X,h_local); Z_Test_local= linh(Test,h_local); 

%Learn ilh hash functions without locality
h = ilh(X,Y,b,sN);
%Binary codes of ilh for training and test points
Z = linh(X,h); Z_Test= linh(Test,h); 

%comparing precision of local subsets and random subsets.

K=[50:50:200]; % Number of neighbors to retrieve
bb=[32]; %number of bits

% Compute the precision using local subsets
ilhP_local=zeros(numel(bb),numel(K));
for l = 1:numel(bb)
  ilhP_local(l,:) = KNNPrecision(Z_local(:,1:bb(l)),Z_Test_local(:,1:bb(l)),K,TY);
	leg_local{l} = ['ilh-local-' num2str(bb(l)) 'bits'];
end

% Compute the precision using random subsets
ilhP=zeros(numel(bb),numel(K));
for l = 1:numel(bb)
  ilhP(l,:) = KNNPrecision(Z(:,1:bb(l)),Z_Test(:,1:bb(l)),K,TY);
	leg{l} = ['ilh-' num2str(bb(l)) 'bits'];
end
prec = [ilhP_local;ilhP]; legs = [leg_local leg];
% ...and plot the results.
figure(1); h = plot(K,prec*100); set(gca,'XTick',K);
xlabel('number of neighbors'); ylabel('precision');
legend(h,legs,'Location','NorthEast');


