% We prune a set of hash functions to find a subset of them that works well
% in retrieval tasks.
% Pruning can be applied to the output of any hash function. Here, we
% already trained ilh on a subset of CIFAR dataset, we applied the hash
% function to a training set, test set and validation set and saved the
% output binary codes in the bincodes.mat


% Load binary codes of training, test and validation sets  and the 
% graound-truth matrices :
% X: N*b binary codes of input data. Here we have N=5000 and b=32.
% T: M*b binary codes of the test data. Here we have N=500 and b=32.
% TY: M*N groumd-truth matrix. (i,j)th element of the matrix is 1 if the 
% ith point in the test set is  similar to the jth point in the training set.
% (i,j)th element is zero if they are dissimilar.
% V: L*b binary codes of the validation set. Here we have L = 100 and b = 32.
% The validation set is used in the pruning to select the best subset of
% 1-bit functions.
% VY: M*N ground-truth affinity between the validation set and the training set.
load('bincodes.mat');


b = size(X,2); % Total number of bits in each code.

% prune the output of the hash functions.
[I,P,L] = bhprune(X,V,VY);


%compare the precision before and after pruning

K=[50:50:200]; % Number of neighbors to retrieve
bb=[8]; %number of bits--> it can be a vector of bits between 1..b

% Compute the precision before pruning
ilhP=zeros(numel(bb),numel(K));
for l = 1:numel(bb)
  ilhP(l,:) = KNNPrecision(X(:,1:bb(l)),T(:,1:bb(l)),K,TY);
	legilh{l} = ['ilh-' num2str(bb(l)) 'bits'];
end

% Compute the precision after pruning
pX=X(:,I);pT=T(:,I);
pruneP=zeros(numel(bb),numel(K));
for l = 1:numel(bb)
  pruneP(l,:) = KNNPrecision(pX(:,1:bb),pT(:,1:bb(l)),K,TY);
  legprun{l} = ['ilh-prune-' num2str(bb(l)) 'bits'];
end
leg = [legilh legprun];

% ...and plot the results.
prec = [ilhP;pruneP];
figure(1); h = plot(K,prec*100); set(gca,'XTick',K);
xlabel('number of neighbors'); ylabel('precision');
legend(h,leg,'Location','NorthEast');
