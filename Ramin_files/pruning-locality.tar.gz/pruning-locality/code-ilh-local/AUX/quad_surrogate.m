% [z] = quad_surrogate(A[,hx,mu,lb_epsilon,maxiter])
%
% Solve a binary quadratic problem z'Az-(2(mu)(z'hx)) as follows:
% - Relax the binary quadratic problem by considering z in the interval
%   [-1 1]^n instead of {0,1}^n, solve the problem approximately using
%   lbfgs, and truncate the results.
% - Since the problem is not convex, it needs an initialization. To find
%   the initializer, convert the binary quadratic problem into a binary 
%   eigenproblem, use spectral relaxation, solve it in the real space by 
%   finding the eigenvector corresponding to the smallest eigenvalue, and 
%   trucate the results.
% - When there is no information about the linear term, mu=[] or hx=[],
%   then the method minimizes only the quadratic part z'Az by setting mu=0
%   and hx=0;
%
%
% In:
%   A: NxN matrix containing contains the coefficients for the quadratic
%      terms.
%   hx: Nx1 vector containing the linear coefficients. Default all zeros.
%   mu: the penalty parameter of the linear term. Default zero.
%   lb_epsilon: the tolerance parameter of the lbfgs. Default: 1e-2.
%   maxiter: max number of iterations of the lbfgs. Default 50.
% Out:
%   z: Nx1 binary code in {-1,1}^n, which is the approximate minimizer of
%      the problem.

% Any non-mandatory argument can be given the value [] to force it to take
% its default value.

% Copyright (c) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan

function [z] = quad_surrogate(A,hx,mu,lb_epsilon,maxiter)

N=size(A,1);
% ---------- Argument defaults ----------
if ~exist('mu','var') || isempty(mu) || ~exist('hx','var') || isempty(hx)
  mu=0; hx=zeros(N,1);
end;
if ~exist('lb_epsilon','var') || isempty(lb_epsilon) lb_epsilon = 1e-2; end;
if ~exist('maxiter','var') || isempty(maxiter) maxiter= 50; end;
% ---------- End of "argument defaults" ----------

%find the initializer
symA = (A+A')/2; %make A symmetric to get real eigenvalues and eigenvectors.
if mu == 0
  [z,~] = eigs(symA,[],1,'sa'); alpha0=1;
else
  temph = -mu*hx;
  newA = [symA .5*(temph)]; newA = [newA;[.5*(temph') 0]];
  [z,~] = eigs(newA,[],1,'sa'); alpha0=z(end); z = z(1:end-1);
end
% We solved a relaxed eigenproblem: we assumed alpha0 is 1, but it could be 
% any number (look at the first equation of page 8 of supp. material).
% if alpha0<0, then z=z*-1 is the approximate solution
if alpha0 < 0 z = z*-1; end
z = z > 0; z = double((2*z)-1); %truncate the results.

% solve the relaxed problem in [-1,1]^n.
N = size(A,1);  oldz =z;
l  = -1 * ones(N,1); u  = ones(N,1); %lower and upper bounds

%prepare the structure
aux_data=cell(0); aux_data{1} = A; aux_data{2} = hx; aux_data{3} = mu;
objFv_func_name='wlinfer_lbfgsb_calc_obj';
grad_func_name='wlinfer_lbfgsb_calc_grad';
try
  z = lbfgsb(z, l, u, objFv_func_name,grad_func_name, aux_data, [], ...
    'factr', lb_epsilon, 'maxiter', maxiter); 
  z = z > 0; z = double((2*z)-1); %truncate the results.
catch err  %if it did not converge
  z = oldz;  %use the initializer as the output.
end
end

