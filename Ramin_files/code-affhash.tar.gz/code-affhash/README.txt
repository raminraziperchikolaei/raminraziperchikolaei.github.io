Matlab code to learn binary hash functions by optimizing an affinity-based
objective functions using MAC.

(C) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan
    Electrical Engineering and Computer Science
    University of California, Merced
    http://eecs.ucmerced.edu

The functions in this package can be used to optimize the affinity-based
objective function, using the method of auxiliary coordinates (MAC). 
The resulting hash function can be used to map input vectors to binary codes,
as a hash function, and thus to do binary hashing for fast approximate 
information retrieval.

Reference:
  R. Raziperchikolaei and M. A. Carreira-Perpinan:
  "Optimizing affinity-based binary hashing using auxiliary coordinates".
  Advances in Neural Information Processing Systems 29 (NIPS 2016), 2016.

The main function is machash.m. See the function for detailed usage
instructions. The script demo.m illustrates how to use them to train hash 
function and do binary hashing using a subset of the CIFAR dataset contained
in the file CIFARsubset.mat.

List of functions:
- demo.m: trains hash functions on the CIFAR subset using 2 methods
  (MACquad and quad) and plots their K-nearest-neighbor precision.
- machash.m (in AUX/): learn binary hash functions by optimizing the 
  affinity-based objective using MAC.

The training algorithm depends on the following functions (in AUX/):
- hOpt: train the hash function given input data and binary codes.
- KNNPrecision: compute K-nearest-neighbor precision.
- linf: apply a linear function to a data matrix.
- linh: apply a linear hash function to a data matrix and return binary codes.
- quad_surrogate: solves a binary quadratic problem approximately using 
    qudratic surrogate method.
- wlinfer_lbfgsb_calc_grad.m: retruns the gradient of a quadratic objective.
    This function is used in the lbfgsb library.
- wlinfer_lbfgsb_calc_obj.m: retruns the value of a quadratic objective.
    This function is used in the lbfgsb library.
- ZOpt: optimize over the binary codes given hash functions. 
    It uses altenating optimization over the bits.

Notes:
- The code currently uses a linear (thresholded) hash function.
  You can use a nonlinear function by providing a corresponding
  training function in the step over the function.
- The code curently uses KSH (BRE) objective function. You use other loss
  functions by changing the step over the codes (look at the ZOpt.m)
- The code curently optimizes the binary quadratic objective using the
  quadratic surrogate method. You can use other solvers by changing the 
  step over the codes and replacing the quad_surrogate.m with a new 
  function (look at the ZOpt.m)

Installation notes:
- We train linear SVMs using LIBLINEAR:
    Fan et al: "LIBLINEAR: a library for large linear classification",
    JMLR 2008, http://www.csie.ntu.edu.tw/~cjlin/liblinear
  and its extension for incremental learning:
    Tsai et al: "Incremental and decremental training for linear
    classification", KDD 2014, http://www.csie.ntu.edu.tw/~cjlin/papers/ws.
  We have provided a Matlab wrapper (matlab/train.c) for the latter by
  modifying the original LIBLINEAR Matlab wrapper.
- We solve the constrained quadratic problem using the a MATLAB interface
  for L-BFGS-B. details can be found at https://github.com/pcarbo/lbfgsb-matlab
- Quick-start instructions:
  1. Install LIBLINEAR:
     change to liblinear-warmstart-1.95/, run 'make'.
  2. Install the Matlab interface of LIBLINEAR:
     change to liblinear-warmstart-1.95/matlab/, run 'make'.
     Make sure MATLABDIR (in Makefile) matches your Matlab filesystem.
  3. To install LBFGS-B, you need to have g++-4.7 and gfortran-4.7 because 
     the version currently supported with MEX is '4.7.x'. 
     Install them using the commands 'sudo apt-get install g++-4.7' and 
     'sudo apt-get install g++-4.7'.
  4. Then create new symbolic links to them. Change to the usr/bin and run:
     'sudo ln -s g++-4.7 g++' and 'sudo ln -s gfortran-4.7 gfortran'.
  5. Install LBFGS-B library. change to lbfgsb-matlab-master/src, run 'make mex'.
     Make sure MATLABDIR (in Makefile) matches your Matlab filesystem.       
     You may need to first install g++-4.7 () and gfortran-4.7 ()
  6. Change to 'lbfgsb-matlab-master/src', and change name of the file 
     'lbfgsb_mex.mexa64' to 'lbfgsb.mexa64'.
  7. Run our code:
     change to the main directory, run 'demo.m'.
     It should take around 30 seconds to run in a workstation.

