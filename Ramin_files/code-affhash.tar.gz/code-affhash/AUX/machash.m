% [h,Z] = machash(X,Y,b,mu,[Z,V,VY])
%
% Optimize an affinity-based objective function using a MAC algorithm.
%
% Notes:
% - We use a validation set V to check the precision at each step. By default,
%   this is a random subset of 1000 points from X, and we do not remove them
%   from the training set. If you want disjoint training and validation sets,
%   provide them explicitly as arguments.
% - To have faster optimization over codes, the affinity matrix Y should be
%   sparse.
%
% In:
%   X: NxD matrix containing N D-dim data points rowwise, the training set.
%   Y: NxN affinity matrix. Contains neighborhood information of the
%      tarining data. The (i,j)th element of Y is 1,-1 or 0 if point i and j
%      are similar, dissimilar, or not related, respectively.
%   b: number of bits in the Hamming space (= number of binary hash functions).
%   mu: list of penalty parameter values; we run one MAC iteration for each.
%   Z: Nxb binary matrix containing N b-bit binary data points (-1/1) rowwise
%      (initial codes). Default: all ones.
%   V: MxD matrix containing M D-dim data points rowwise, the validation set.
%      We skip a value of mu if the precision on V does not increase.
%      Default: 1000 points randomly selected from dataset X.
%   VY: MxN affinity matrix contains the neighborhood information between
%      the points in the validation set and the points in the training set.
%      The (i,j)th elemens of VY is 1 if validation point i is similar to
%      the training point j. The points are considered dissimilar
%      otherwise.
% Out:
%   h: hash function. It is a struct with parameters:
%      type = 'linh', W = weight matrix (of bxD), w = bias vector (of bx1).
%   Z: NxL binary matrix, final codes. It equals the output of h(X).

% Any non-mandatory argument can be given the value [] to force it to take
% its default value.

% Copyright (c) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan

function [h,Z] = machash(X,Y,b,mu,Z,V,VY)

N=size(X,1); %size of the training set.

% ---------- Argument defaults ----------
if ~exist('Z','var') || isempty(Z) Z = ones(N,b); end;
if ~exist('V','var') || isempty(V) || ~exist('VY','var') || isempty(VY) 
  idx = randperm(N,1000); V=X(idx,:); VY = Y(idx,:);
end;
% ---------- End of "argument defaults" ----------

mkdir BAtemp %Create a temporary folder for liblinear files

% Initializations
h = []; oldP=0; hX=[];Z_old=[];old_Zsim=[];

% We need to compute the Zsim = Z*Z' for the related points 
% (with the affinity value of 1 or -1). This will be used in the Z-step.
[r,c] = find(Y~=0);  temp=sum(Z(r,:).*Z(c,:),2); 
Zsim = sparse(r,c,temp,N,N);

SX = sparse(X);		% LIBLINEAR requires a sparse data matrix
i = 1; 
while i <= numel(mu)
  
  % Train the hash function
  h_old = h; hX_old=hX;
  [h,hX] = hOpt(Z,SX,h,[]); hX = 2*hX - 1; 
 
  % Check precision on validation set before Z step
  newP = KNNPrecision(linh(X,h),linh(V,h),1000,VY);
  
  % Skip the step if the precision does not increase
  if newP < oldP 
    Zsim = old_Zsim;
    h = h_old; Z = Z_old; hX=hX_old;   
  else
    oldP = newP;
  end
  
  % Train the binary codes (Z step)
  Z_old = Z; old_Zsim=Zsim;
  [Z,Zsim] = ZOpt(Y,hX,mu(i),Z,Zsim);
  
  % Stop when the output of the hash function equals the binary codes
  if all(hX(:)==Z(:)) break; end
  i = i + 1;
end
Z = hX;

delete('BAtemp/*'); rmdir BAtemp %remove the temporary folder
end

