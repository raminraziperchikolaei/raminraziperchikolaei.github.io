% [I,P,L] = bhprune(X,T,grtr[,k,p])
%
% Prune a set of 1-bit hash functions. Pruning can be applied to the output 
% of any hashing method. To prune the hash functions, bhprune only needs the
% output binary codes of the hash function on a validation and training set. 
% Given the binary codes (b-bit vectors) for a training set and a test set, 
% bhprune constructs an approximately optimal subset of functions (bits) by 
% greedily adding, one by one the function having best precision for the queries
% in T on the base set X. 
%
% In:
%   X: Nxb matrix containing N b-bit codes of the base set.
%   T: Mxb matrix containing M b-bit codes of the test set.
%   grtr: MxN groumd-truth matrix. (i,j)th element of the matrix is 1 if the 
%      ith point in the test set is similar to the jth point in the base set.
%      (i,j)th element is zero if the points are dissimilar.
%   k: Number of retrieved points of each query in computing the precision.
%      Default: 100.
%   p: scalar in (0,1], the proportion of the maximal precision desired.
%      Default: 0.95.
% Out:
%   I: ordered list of b indices giving the optimal set of hash functions 
%      (bits), ie I(1:L) contains the index of L bits (functions) giving 
%      highest precision over all sets of L bits codes (approximately, based
%      on a greedy algorithm).
%   P: 1xb list, P(i) is the precision achieved using the functions I(1:i).
%   L: scalar in [1,b] such that the functions with indices I(1:L) achieve a 
%      proportion p of the maximal precision.
%
% Note: the highest precision may be achieved using L < b functions, ie using
% all b original bits (functions) need not give the highest precision.
%
% Reference:
% - R. Raziperchikolaei and  M. A. Carreira-Perpinan: "Learning independent, 
% diverse binary hash functions: pruning and locality".

% Any non-mandatory argument can be given the value [] to force it to take
% its default value.

% Copyright (c) 2016 by Ramin Raziperchikolaei and Miguel A. Carreira-Perpinan

function [I,P,L] = bhprune(X,T,grtr,k,p)

% ---------- Argument defaults ----------
if ~exist('k','var') || isempty(k) k = 100; end;
if ~exist('p','var') || isempty(p) p = 0.95; end;
% ---------- End of "argument defaults" ----------

[N,b]=size(X); [M,~]=size(T);

rest=1:1:b; % contains the remaining bits to ckeck.

% Hamming distance between the binary code of base set and the test set
hDist = zeros(M,N,'uint16');
P = zeros(1,b); I = zeros(1,b);
for i = 1 : b
  prec = zeros(1,b);  
  for j=rest %for eahc bit
    tempDist =  uint16(bsxfun(@xor,T(:,j),X(:,j)')) + hDist; %compute the Hamming distance
    prec(j)= PrunePrecision(tempDist,grtr,k); % and comute the precision.
  end
  [m,idx] = max(prec); %Which bit gives the maximum precision?
  P(i)=m; I(i)=idx; % store the index of the bit and its precision
  
  %update the Hamming distances using the selected bit.
  hDist = hDist + uint16(bsxfun(@xor,T(:,idx),X(:,idx)'));
  rest=setdiff(rest,idx); % update list of the remaining bits.
end
%find the number of bits needed to achieve 95% of the precision using all bits. 
L=find(p*max(P) ,1); 

% [precision] = PrunePrecision(distM,grtr,k) 
% Compute K-nearest neighbors precision.
%
% Given the Hamming distance between the test set of size M and base set of
% size N. and the MxN ground-truth similarity between the the sets, it
% compute the nearest neighbors precision.
%
% In:
%   distM: MxN matrix containing the Hamming distances between the M test 
%      points and the N training points.
%   grtr: MxN groumd-truth matrix. (i,j)th element of the matrix is 1 if the 
%      ith point in the test set is  similar to the jth point in the base set.
%      (i,j)th element is zero if they are dissimilar.
%   k: Number of retrieved points of each query in computing the precision.
% Out:
%   precision: the k-nearest neighbors precision in the binary space.

function [precision] = PrunePrecision(distM,grtr,k)
[numTest,~] = size(distM); [~,idxM] = sort(distM,2);
idxM=idxM(:,1:k); simM=false((size(grtr)));
for i =1:numTest
  simM(i,idxM(i,:))=1;
end
simM=simM & grtr;
retrievedGoodPairs = sum(simM(:));
precision = retrievedGoodPairs/(k*numTest);


